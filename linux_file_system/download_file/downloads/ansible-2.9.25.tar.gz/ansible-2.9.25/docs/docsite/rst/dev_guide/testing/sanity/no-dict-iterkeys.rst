no-dict-iterkeys
================

The ``dict.iterkeys`` method has been removed in Python 3. Use the following instead:

.. code-block:: python

    for KEY in DICT:
        pass
