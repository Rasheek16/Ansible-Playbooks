:orphan:

.. _vmware_ansible_getting_started:

***************************************
Getting Started with Ansible for VMware
***************************************

This will have a basic "hello world" scenario/walkthrough that gets the user introduced to the basics.
